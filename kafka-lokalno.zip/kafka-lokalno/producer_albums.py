from requests import get
import common_functions as cf
import json
import csv
import time

topic = "albums"
header = cf.get_auth_header(cf.get_token())

producer = cf.producer

producer.flush()

with open('artists_spotify.csv', mode ='r')as file:
  csvFile = csv.reader(file)
  for lines in csvFile:
        id = lines[0].split(":")[2]
        r = get("https://api.spotify.com/v1/artists/" + id + "/albums?limit=5", headers = header).json()
        producer.produce(topic, value = json.dumps(r, indent=2).encode('utf-8'))
        producer.flush()
        time.sleep(1)