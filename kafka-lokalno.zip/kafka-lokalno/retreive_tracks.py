import csv
import json
from dotenv import load_dotenv
import os
import base64
from requests import post, get
from confluent_kafka import Producer

load_dotenv()

client_id = os.getenv("CLIENT_ID")
client_secret = os.getenv("CLIENT_SECRET")


def get_token():
    auth_string = client_id + ":" + client_secret
    auth_bytes = auth_string.encode("utf-8")
    auth_base64 = str(base64.b64encode(auth_bytes), "utf-8")

    url = "https://accounts.spotify.com/api/token"
    headers = {
        "Authorization": "Basic " + auth_base64,
        "Content-Type": "application/x-www-form-urlencoded"
    }
    data = {"grant_type": "client_credentials"}
    result = post(url, headers=headers, data=data)

    json_result = json.loads(result.content)
    token = json_result["access_token"]
    return token

def get_auth_header(token):
    return {"Authorization": "Bearer " + token}

conf = {
    'bootstrap.servers': 'localhost:9092'
}

producer = Producer(conf)
topic = "spotify_tracks"
header = get_auth_header(get_token())
print(header)
markets_all = open("markets.txt", "r")
markets = markets_all.readline().split(" ")
producer.flush()
with open('artists_spotify.csv', mode ='r')as file:
  csvFile = csv.reader(file)
  for lines in csvFile:
        for m in markets:
            id = lines[0].split(":")[2]
            r = get("https://api.spotify.com/v1/artists/" + id + "/top-tracks?market=" + m, headers = header).json()
            producer.produce(topic, value = json.dumps(r, indent=2).encode('utf-8'))
            producer.flush()
