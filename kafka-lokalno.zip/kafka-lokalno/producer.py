import requests
import json
import time
import datetime
from confluent_kafka import Producer

conf = {
    'bootstrap.servers': 'localhost:9092'
}
producer = Producer(conf)

base_url = 'https://api.spotify.com/v1/artists/4KbPZAIKXaOCljIUeps1aG?si=vEBD6qaaTp2eLOIbA4bxnA'

headers = {
    'Authorization': 'Bearer  BQB01GuZ06oRmknhV5qAa67xqvasDRjzKxv4yHwD3Fm4VxGGV3s6ezxIV-JCFBcCcSGujJMVRXO4gnW4uNMWLd7-4m8yHZ06SwsbbExGhrZBgZiZ-i9H'
}
cryptocurrency = 'bitcoin'

current_time = int(time.time()) * 1000
start_time = current_time - 100*24*60*60*1000

#Razdvojeno u 4 poziva jer je maksimalni opseg za interval h1 (jedan sat) 30 dana
for i in range(4):
    period_start_time = start_time + i*25*24*60*60*1000
    period_end_time = period_start_time + 25*24*60*60*1000

    params = {
        'start': period_start_time,
        'end': period_end_time,
        'interval': 'h1'
    }

    response = requests.get(base_url, params=params, headers=headers)
    data = json.loads(response.text)
    print(data)
    
    for hour_data in data['data']:
        message = f"{(hour_data['time'])},{hour_data['priceUsd']}"
        print(message)
        producer.produce(cryptocurrency, key=cryptocurrency, value=message.encode('utf-8'))

producer.flush()
